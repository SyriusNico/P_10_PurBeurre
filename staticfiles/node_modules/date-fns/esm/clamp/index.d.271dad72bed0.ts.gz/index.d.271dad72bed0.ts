// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { clamp } from 'date-fns'
export default clamp

// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../addMonths/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var addMonths = convertToFP(fn, 2);
export default addMonths;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../differenceInSeconds/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var differenceInSecondsWithOptions = convertToFP(fn, 3);
export default differenceInSecondsWithOptions;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../eachMinuteOfInterval/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var eachMinuteOfIntervalWithOptions = convertToFP(fn, 2);
export default eachMinuteOfIntervalWithOptions;
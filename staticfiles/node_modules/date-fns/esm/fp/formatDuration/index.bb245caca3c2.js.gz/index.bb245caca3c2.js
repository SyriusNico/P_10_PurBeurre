// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../formatDuration/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var formatDuration = convertToFP(fn, 1);
export default formatDuration;
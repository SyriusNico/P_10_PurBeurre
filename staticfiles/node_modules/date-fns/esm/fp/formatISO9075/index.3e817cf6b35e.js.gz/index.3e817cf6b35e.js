// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../formatISO9075/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var formatISO9075 = convertToFP(fn, 1);
export default formatISO9075;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../formatRFC7231/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var formatRFC7231 = convertToFP(fn, 1);
export default formatRFC7231;
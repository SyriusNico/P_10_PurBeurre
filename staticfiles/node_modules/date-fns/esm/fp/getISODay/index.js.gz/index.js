// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getISODay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getISODay = convertToFP(fn, 1);
export default getISODay;
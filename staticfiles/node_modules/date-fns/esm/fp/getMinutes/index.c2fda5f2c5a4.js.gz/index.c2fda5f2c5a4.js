// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getMinutes/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getMinutes = convertToFP(fn, 1);
export default getMinutes;
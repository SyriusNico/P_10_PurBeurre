// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getQuarter/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getQuarter = convertToFP(fn, 1);
export default getQuarter;
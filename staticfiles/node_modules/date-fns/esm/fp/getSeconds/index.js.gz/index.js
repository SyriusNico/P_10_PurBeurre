// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getSeconds/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getSeconds = convertToFP(fn, 1);
export default getSeconds;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getWeekOfMonth/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getWeekOfMonth = convertToFP(fn, 1);
export default getWeekOfMonth;
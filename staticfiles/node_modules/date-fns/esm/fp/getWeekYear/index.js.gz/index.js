// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../getWeekYear/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var getWeekYear = convertToFP(fn, 1);
export default getWeekYear;
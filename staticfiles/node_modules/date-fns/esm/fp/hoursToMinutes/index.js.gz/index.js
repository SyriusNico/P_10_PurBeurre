// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../hoursToMinutes/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var hoursToMinutes = convertToFP(fn, 1);
export default hoursToMinutes;
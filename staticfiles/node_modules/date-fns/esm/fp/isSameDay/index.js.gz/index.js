// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../isSameDay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var isSameDay = convertToFP(fn, 2);
export default isSameDay;
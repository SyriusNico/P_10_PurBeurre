// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../isSameISOWeek/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var isSameISOWeek = convertToFP(fn, 2);
export default isSameISOWeek;
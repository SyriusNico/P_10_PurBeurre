// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../isSaturday/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var isSaturday = convertToFP(fn, 1);
export default isSaturday;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../lastDayOfWeek/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var lastDayOfWeek = convertToFP(fn, 1);
export default lastDayOfWeek;
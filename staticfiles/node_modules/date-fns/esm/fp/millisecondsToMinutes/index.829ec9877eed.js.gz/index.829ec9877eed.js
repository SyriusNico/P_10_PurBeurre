// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../millisecondsToMinutes/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var millisecondsToMinutes = convertToFP(fn, 1);
export default millisecondsToMinutes;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../minutesToHours/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var minutesToHours = convertToFP(fn, 1);
export default minutesToHours;
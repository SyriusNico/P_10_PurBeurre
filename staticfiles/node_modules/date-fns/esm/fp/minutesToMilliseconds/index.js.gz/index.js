// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../minutesToMilliseconds/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var minutesToMilliseconds = convertToFP(fn, 1);
export default minutesToMilliseconds;
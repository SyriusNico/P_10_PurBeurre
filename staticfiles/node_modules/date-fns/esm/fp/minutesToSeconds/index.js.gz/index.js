// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../minutesToSeconds/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var minutesToSeconds = convertToFP(fn, 1);
export default minutesToSeconds;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../nextDay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var nextDay = convertToFP(fn, 2);
export default nextDay;
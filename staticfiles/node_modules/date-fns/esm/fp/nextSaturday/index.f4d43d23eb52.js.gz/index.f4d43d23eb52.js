// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../nextSaturday/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var nextSaturday = convertToFP(fn, 1);
export default nextSaturday;
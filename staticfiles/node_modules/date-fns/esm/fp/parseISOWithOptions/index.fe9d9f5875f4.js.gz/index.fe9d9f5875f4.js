// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../parseISO/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var parseISOWithOptions = convertToFP(fn, 2);
export default parseISOWithOptions;
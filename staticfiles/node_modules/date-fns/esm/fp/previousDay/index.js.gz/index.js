// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../previousDay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var previousDay = convertToFP(fn, 2);
export default previousDay;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../previousSunday/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var previousSunday = convertToFP(fn, 1);
export default previousSunday;
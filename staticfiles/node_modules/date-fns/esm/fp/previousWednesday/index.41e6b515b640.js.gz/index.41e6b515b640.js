// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../previousWednesday/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var previousWednesday = convertToFP(fn, 1);
export default previousWednesday;
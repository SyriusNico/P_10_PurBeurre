// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../quartersToMonths/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var quartersToMonths = convertToFP(fn, 1);
export default quartersToMonths;
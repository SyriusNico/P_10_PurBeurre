// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../secondsToMinutes/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var secondsToMinutes = convertToFP(fn, 1);
export default secondsToMinutes;
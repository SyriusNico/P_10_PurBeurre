// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../setDay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var setDay = convertToFP(fn, 2);
export default setDay;
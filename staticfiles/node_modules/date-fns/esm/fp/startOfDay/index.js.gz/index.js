// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../startOfDay/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var startOfDay = convertToFP(fn, 1);
export default startOfDay;
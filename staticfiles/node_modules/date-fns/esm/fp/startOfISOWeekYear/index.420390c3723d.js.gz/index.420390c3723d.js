// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../startOfISOWeekYear/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var startOfISOWeekYear = convertToFP(fn, 1);
export default startOfISOWeekYear;
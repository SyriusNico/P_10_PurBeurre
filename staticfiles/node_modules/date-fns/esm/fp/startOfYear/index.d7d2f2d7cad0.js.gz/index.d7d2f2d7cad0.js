// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../startOfYear/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var startOfYear = convertToFP(fn, 1);
export default startOfYear;
// This file is generated automatically by `scripts/build/fp.js`. Please, don't change it.
import fn from "../../subISOWeekYears/index.js";
import convertToFP from "../_lib/convertToFP/index.js";
var subISOWeekYears = convertToFP(fn, 2);
export default subISOWeekYears;
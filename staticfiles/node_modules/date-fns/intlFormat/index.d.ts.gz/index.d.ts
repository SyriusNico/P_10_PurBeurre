// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { intlFormat } from 'date-fns'
export default intlFormat

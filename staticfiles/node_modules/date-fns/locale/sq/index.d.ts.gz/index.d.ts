// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { sq } from 'date-fns/locale'
export default sq

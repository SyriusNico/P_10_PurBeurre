// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { nextFriday } from 'date-fns'
export default nextFriday

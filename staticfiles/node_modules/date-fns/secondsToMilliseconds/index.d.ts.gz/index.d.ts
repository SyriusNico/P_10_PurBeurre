// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { secondsToMilliseconds } from 'date-fns'
export default secondsToMilliseconds
